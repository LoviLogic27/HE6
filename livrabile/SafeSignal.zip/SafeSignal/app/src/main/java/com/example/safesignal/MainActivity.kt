package com.example.safesignal

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Shader
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.cloudinary.android.MediaManager
import com.cloudinary.android.callback.ErrorInfo
import com.cloudinary.android.callback.UploadCallback
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.maps.android.compose.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.layout.navigationBarsPadding

const val CLOUDINARY_CLOUD_NAME = "dvurc8prx"
const val CLOUDINARY_UPLOAD_PRESET = "safe_signal_unsigned"

val Bg = Color(0xFF06070B)
val CardBg = Color(0xFF171821)
val Primary = Color(0xFFFF2D3D)
val Danger = Color(0xFFFF1744)
val Safe = Color(0xFF4CAF50)
val Warning = Color(0xFFFFA726)
val Info = Color(0xFF42A5F5)
val Dark = Color(0xFFF5F6FA)
val Muted = Color(0xFFA9AAB5)
val SoftRed = Color(0xFF3A0D14)
val Panel = Color(0xFF11121A)
val Panel2 = Color(0xFF20212B)

data class FriendLocation(
    val uid: String = "",
    val name: String = "",
    val phone: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val profileImageUrl: String = "",
    val online: Boolean = false,
    val lastSeen: Long = 0L,
    val shareLocation: Boolean = true
)

data class FriendRequest(
    val senderUid: String = "",
    val senderName: String = "",
    val senderPhone: String = "",
    val senderProfileImageUrl: String = ""
)

data class SentFriendRequest(
    val receiverUid: String = "",
    val receiverName: String = "",
    val receiverPhone: String = "",
    val receiverProfileImageUrl: String = ""
)

data class UserProfile(
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val profileImageUrl: String = "",
    val online: Boolean = false,
    val lastSeen: Long = 0L,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val shareLocation: Boolean = true
)

data class AlertHistoryItem(
    val alertId: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val type: String = "",
    val message: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val timestamp: Long = 0L
)

data class ShelterLocation(
    val name: String = "",
    val type: String = "",
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val description: String = ""
)

class MainActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private var onPermissionGranted: (() -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val smsGranted = permissions[Manifest.permission.SEND_SMS] == true
            val locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true

            if (smsGranted && locationGranted) {
                onPermissionGranted?.invoke()
            } else {
                Toast.makeText(this, "SMS and location permissions are required", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance(
            "https://safesignal-bb61d-default-rtdb.europe-west1.firebasedatabase.app"
        )

        try {
            MediaManager.init(this, mapOf("cloud_name" to CLOUDINARY_CLOUD_NAME))
        } catch (_: Exception) {}

        setContent {
            MaterialTheme {
                SafeSignalApp(
                    auth = auth,
                    database = database,
                    requestPermissions = { action ->
                        onPermissionGranted = action

                        val permissions = mutableListOf(
                            Manifest.permission.SEND_SMS,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
                        }

                        permissionLauncher.launch(permissions.toTypedArray())
                    }
                )
            }
        }
    }
}

@Composable
fun SafeSignalApp(auth: FirebaseAuth, database: FirebaseDatabase, requestPermissions: (() -> Unit) -> Unit) {
    var screen by remember { mutableStateOf(if (auth.currentUser != null) "main" else "login") }

    LaunchedEffect(screen, auth.currentUser?.uid) {
        if (screen == "main" && auth.currentUser != null) setupOnlinePresence(auth, database)
    }

    when (screen) {
        "login" -> LoginScreen(auth, database, { screen = "signup" }, { screen = "main" })
        "signup" -> SignUpScreen(auth, database, { screen = "login" }, { screen = "main" })
        "main" -> MainAppScreen(
            auth = auth,
            database = database,
            logout = {
                setUserOnline(auth, database, false)
                auth.signOut()
                screen = "login"
            },
            requestPermissions = requestPermissions
        )
    }
}

@Composable
fun SafeSignalLogoRow(
    modifier: Modifier = Modifier,
    titleSize: Int = 24,
    logoSize: Int = 40,
    centered: Boolean = false
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (centered) Arrangement.Center else Arrangement.Start
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "App Logo",
            modifier = Modifier.size(logoSize.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(text = "SafeSignal", fontSize = titleSize.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
fun AuthShell(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF2A050B), Color(0xFF120308), Bg, Color(0xFF07080D))
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(320.dp)
                .background(Brush.radialGradient(listOf(Primary.copy(alpha = 0.34f), Color.Transparent)), CircleShape)
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(34.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg.copy(alpha = 0.96f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
            elevation = CardDefaults.cardElevation(16.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                SafeSignalLogoRow(titleSize = 30, logoSize = 48, centered = true)
                Spacer(Modifier.height(12.dp))
                Text(subtitle, fontSize = 15.sp, color = Color.White)
                Spacer(Modifier.height(24.dp))
                content()
            }
        }
    }
}

@Composable
fun LoginScreen(auth: FirebaseAuth, database: FirebaseDatabase, goToSignUp: () -> Unit, goToMain: () -> Unit) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    AuthShell("Safe Signal", "Login to continue") {
        ModernField(email, { email = it }, "Email")
        Spacer(Modifier.height(12.dp))
        ModernField(password, { password = it }, "Password", password = true)
        Spacer(Modifier.height(20.dp))
        PrimaryButton("Login") {
            if (email.isBlank() || password.isBlank()) Toast.makeText(context, "Complete all fields", Toast.LENGTH_SHORT).show()
            else auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    setupOnlinePresence(auth, database)
                    Toast.makeText(context, "Login successful", Toast.LENGTH_SHORT).show()
                    goToMain()
                } else Toast.makeText(context, "Login failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
            }
        }
        TextButton(onClick = goToSignUp) { Text("Don't have an account? Sign up", color = Primary) }
    }
}

@Composable
fun SignUpScreen(auth: FirebaseAuth, database: FirebaseDatabase, goToLogin: () -> Unit, goToMain: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isCreatingAccount by remember { mutableStateOf(false) }
    val imagePickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> selectedImageUri = uri }

    Box(modifier = Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(24.dp))
            Text("Create Account", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Primary)
            Text("Join Safe Signal", fontSize = 15.sp, color = Color.White)
            Spacer(Modifier.height(16.dp))

            ProfilePhotoPicker(selectedImageUri, null) { imagePickerLauncher.launch("image/*") }
            Spacer(Modifier.height(14.dp))

            ModernField(name, { name = it }, "Full Name")
            ModernField(phone, { phone = it }, "Phone Number")
            ModernField(email, { email = it }, "Email")
            ModernField(password, { password = it }, "Password", password = true)
            ModernField(confirmPassword, { confirmPassword = it }, "Confirm Password", password = true)
            Spacer(Modifier.height(12.dp))

            Button(
                onClick = {
                    when {
                        isCreatingAccount -> Toast.makeText(context, "Please wait", Toast.LENGTH_SHORT).show()
                        name.isBlank() || phone.isBlank() || email.isBlank() || password.isBlank() || confirmPassword.isBlank() -> Toast.makeText(context, "Complete all required fields", Toast.LENGTH_SHORT).show()
                        password != confirmPassword -> Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
                        password.length < 6 -> Toast.makeText(context, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                        else -> {
                            isCreatingAccount = true
                            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                                if (!task.isSuccessful) {
                                    isCreatingAccount = false
                                    Toast.makeText(context, "Sign up failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                                    return@addOnCompleteListener
                                }
                                val userId = auth.currentUser?.uid ?: run { isCreatingAccount = false; goToMain(); return@addOnCompleteListener }
                                val baseUserData = mapOf(
                                    "name" to name, "phone" to phone.trim(), "email" to email,
                                    "profileImageUrl" to "", "latitude" to 0.0, "longitude" to 0.0,
                                    "online" to true, "lastSeen" to ServerValue.TIMESTAMP, "shareLocation" to true
                                )
                                database.reference.child("users").child(userId).setValue(baseUserData).addOnCompleteListener { dbTask ->
                                    if (!dbTask.isSuccessful) {
                                        isCreatingAccount = false
                                        Toast.makeText(context, "Database error: ${dbTask.exception?.message}", Toast.LENGTH_LONG).show()
                                        goToMain(); return@addOnCompleteListener
                                    }
                                    setupOnlinePresence(auth, database)
                                    if (selectedImageUri != null) {
                                        uploadProfileImageToCloudinary(context, selectedImageUri!!, onSuccess = { imageUrl ->
                                            database.reference.child("users").child(userId).child("profileImageUrl").setValue(imageUrl).addOnCompleteListener {
                                                isCreatingAccount = false
                                                Toast.makeText(context, "Account created", Toast.LENGTH_SHORT).show()
                                                goToMain()
                                            }
                                        }, onError = { error ->
                                            isCreatingAccount = false
                                            Toast.makeText(context, "Photo upload failed: $error", Toast.LENGTH_LONG).show()
                                            goToMain()
                                        })
                                    } else {
                                        isCreatingAccount = false
                                        Toast.makeText(context, "Account created", Toast.LENGTH_SHORT).show()
                                        goToMain()
                                    }
                                }
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                enabled = !isCreatingAccount,
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary)
            ) { Text(if (isCreatingAccount) "Creating..." else "Sign Up", fontWeight = FontWeight.Bold) }
            TextButton(onClick = goToLogin) { Text("Already have an account? Login", color = Primary) }
        }
    }
}

@Composable
fun MainAppScreen(
    auth: FirebaseAuth,
    database: FirebaseDatabase,
    logout: () -> Unit,
    requestPermissions: (() -> Unit) -> Unit
) {
    var currentScreen by remember { mutableStateOf("home") }
    var statusText by remember { mutableStateOf("Press SOS in case of emergency") }
    val context = LocalContext.current
    var askedInitialPermissions by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!askedInitialPermissions) {
            askedInitialPermissions = true

            val alreadyAsked = context
                .getSharedPreferences("safe_signal_data", Context.MODE_PRIVATE)
                .getBoolean("initial_permissions_asked", false)

            if (!alreadyAsked) {
                context
                    .getSharedPreferences("safe_signal_data", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("initial_permissions_asked", true)
                    .apply()

                requestPermissions {
                    startSafeSignalBackgroundService(context)
                }
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF180609), Bg, Color(0xFF090A10))))
                .padding(horizontal = 16.dp)
        ) {
            AppHeader(auth.currentUser?.email ?: "Logged in", logout)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = 0.92f)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        NavItem("Home", currentScreen == "home") { currentScreen = "home" }
                        NavItem("Friends", currentScreen == "friends") { currentScreen = "friends" }
                        NavItem("Maps", currentScreen == "maps") { currentScreen = "maps" }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth()) {
                        NavItem("Alerts", currentScreen == "alerts") { currentScreen = "alerts" }
                        NavItem("Profile", currentScreen == "profile") { currentScreen = "profile" }
                        NavItem("History", currentScreen == "history") { currentScreen = "history" }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth()) {
                        NavItem("Shelters", currentScreen == "shelters") { currentScreen = "shelters" }
                        NavItem("About", currentScreen == "about") { currentScreen = "about" }
                        Spacer(modifier = Modifier.weight(1f).height(34.dp).padding(horizontal = 3.dp))
                    }

                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
            ){
                when (currentScreen) {
                    "home" -> HomeSafeScreen(auth, database, statusText, { statusText = it }, requestPermissions)
                    "friends" -> FriendsScreen(auth, database)
                    "maps" -> MapsScreen(auth, database, requestPermissions)
                    "alerts" -> DangerAlertsScreen(auth, database, requestPermissions)
                    "profile" -> ProfileScreen(auth, database)
                    "history" -> HistoryScreen(auth, database)
                    "shelters" -> SheltersScreen()
                    "about" -> AboutScreen()
                }
            }
        }
    }
}

@Composable
fun RowScope.NavItem(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.weight(1f).height(34.dp).padding(horizontal = 3.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) Primary.copy(alpha = 0.22f) else Panel2.copy(alpha = 0.55f),
            contentColor = if (selected) Color.White else Muted
        ),
        border = if (selected) BorderStroke(1.dp, Primary.copy(alpha = 0.55f)) else BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
    ) {
        Text(text, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
fun AppHeader(email: String, logout: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg.copy(alpha = 0.94f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        elevation = CardDefaults.cardElevation(12.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                SafeSignalLogoRow(titleSize = 22, logoSize = 38)
                Spacer(Modifier.height(3.dp))
                Text(email, fontSize = 12.sp, color = Color.White)
            }
            Button(
                onClick = logout,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary.copy(alpha = 0.18f)),
                border = BorderStroke(1.dp, Primary.copy(alpha = 0.45f)),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) { Text("Logout", fontSize = 11.sp, color = Color.White) }
        }
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        if (subtitle != null) {
            Spacer(Modifier.height(4.dp))
            Text(subtitle, fontSize = 14.sp, color = Color.White)
        }
    }
}

@Composable
fun PrimaryButton(text: String, color: Color = Primary, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 12.dp, pressedElevation = 4.dp)
    ) { Text(text, fontWeight = FontWeight.Bold, color = Color.White) }
}

@Composable
fun ModernField(value: String, onChange: (String) -> Unit, label: String, password: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, color = Color.White) },
        singleLine = !label.contains("message", true),
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        textStyle = LocalTextStyle.current.copy(color = Color.White),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        shape = RoundedCornerShape(18.dp)
    )
}

@Composable
fun ProfilePhotoPicker(uri: Uri?, imageUrl: String?, onClick: () -> Unit) {
    val model: Any? = uri ?: imageUrl?.ifBlank { null }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (model != null) AsyncImage(model = model, contentDescription = "Profile image", modifier = Modifier.size(96.dp).clip(CircleShape))
        else Surface(modifier = Modifier.size(96.dp).clip(CircleShape), color = SoftRed) { Box(contentAlignment = Alignment.Center) { Text("Photo", color = Color.White, fontWeight = FontWeight.Bold) } }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onClick,
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Panel2),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
        ) { Text("Choose Photo", color = Color.White) }
    }
}

@Composable
fun HomeSafeScreen(auth: FirebaseAuth, database: FirebaseDatabase, statusText: String, onStatusChange: (String) -> Unit, requestPermissions: (() -> Unit) -> Unit) {
    val context = LocalContext.current
    var acceptedFriends by remember { mutableStateOf<List<FriendLocation>>(emptyList()) }
    ListenAcceptedFriends(auth, database) { acceptedFriends = it }

    val infiniteTransition = rememberInfiniteTransition(label = "sosPulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 1350), repeatMode = RepeatMode.Reverse),
        label = "pulse"
    )
    var sosPressed by remember { mutableStateOf(false) }
    val sosScale by animateFloatAsState(targetValue = if (sosPressed) 0.92f else 1f, label = "sosScale")

    LaunchedEffect(sosPressed) {
        if (sosPressed) {
            delay(120)
            sosPressed = false
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(206.dp)) {
            Surface(
                modifier = Modifier.size(206.dp).graphicsLayer { scaleX = pulse; scaleY = pulse; alpha = 0.42f },
                shape = CircleShape,
                color = Primary.copy(alpha = 0.16f),
                border = BorderStroke(2.dp, Primary.copy(alpha = 0.55f))
            ) {}
            Surface(
                modifier = Modifier.size(180.dp).graphicsLayer {
                    scaleX = 0.96f + (pulse - 0.88f) * 0.32f
                    scaleY = 0.96f + (pulse - 0.88f) * 0.32f
                    alpha = 0.62f
                },
                shape = CircleShape,
                color = Primary.copy(alpha = 0.22f),
                border = BorderStroke(2.dp, Primary.copy(alpha = 0.70f))
            ) {}
            Surface(modifier = Modifier.size(156.dp), shape = CircleShape, color = Color(0xFF34070D), border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))) {}
            Button(
                onClick = {
                    sosPressed = true
                    if (acceptedFriends.isEmpty()) {
                        Toast.makeText(context, "Add accepted friends first", Toast.LENGTH_LONG).show()
                    } else {
                        requestPermissions {
                            try {
                                startSafeSignalBackgroundService(context)
                                showSafeSignalNotification(context, "🚨 SOS Sent", "Alert sent to your trusted friends")
                            } catch (e: Exception) {
                                Toast.makeText(context, "Notification error: ${e.message}", Toast.LENGTH_LONG).show()
                            }

                            val location = getLastKnownLocation(context)
                            saveAlertToFirebase(auth, database, "SOS", "SOS ALERT! I need help.", location, acceptedFriends)
                            sendSOS(context, acceptedFriends)
                            onStatusChange("SOS alert sent to ${acceptedFriends.size} accepted friend(s)")
                        }
                    }
                },
                modifier = Modifier.size(150.dp).graphicsLayer { scaleX = sosScale; scaleY = sosScale },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Danger),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 24.dp, pressedElevation = 10.dp)
            ) {
                Text("SOS", fontSize = 46.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = 0.92f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Text(statusText, modifier = Modifier.padding(18.dp), fontSize = 15.sp, color = Color.White)
        }

        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = 0.92f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Button(
                    onClick = {
                        if (acceptedFriends.isEmpty()) Toast.makeText(context, "Add accepted friends first", Toast.LENGTH_SHORT).show()
                        else requestPermissions {
                            val location = getLastKnownLocation(context)
                            saveAlertToFirebase(auth, database, "SAFE", "SAFE CHECK-IN: I am safe.", location, acceptedFriends)
                            showSafeSignalNotification(context, "✅ Safe Check-In", "Your friends were notified that you are safe")
                            sendSafeCheckIn(context, acceptedFriends)
                            onStatusChange("Safety check-in sent")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Safe)
                ) { Text("Safe Check-In", fontWeight = FontWeight.Bold, color = Color.White) }

                Spacer(Modifier.height(10.dp))


            }
        }

        Spacer(Modifier.height(14.dp))
        Text("Accepted friends: ${acceptedFriends.size}", fontSize = 13.sp, color = Color.White)
    }
}

@Composable
fun FriendsScreen(auth: FirebaseAuth, database: FirebaseDatabase) {
    val context = LocalContext.current
    val myUid = auth.currentUser?.uid
    var friendPhone by remember { mutableStateOf("") }
    var requests by remember { mutableStateOf<List<FriendRequest>>(emptyList()) }
    var sentRequests by remember { mutableStateOf<List<SentFriendRequest>>(emptyList()) }
    var friends by remember { mutableStateOf<List<FriendLocation>>(emptyList()) }

    DisposableEffect(myUid) {
        if (myUid == null) onDispose {} else {
            val requestsRef = database.reference.child("friendRequests").child(myUid)
            val requestListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    requests = snapshot.children.mapNotNull { child ->
                        val senderUid = child.key ?: return@mapNotNull null
                        val status = child.child("status").getValue(String::class.java) ?: "pending"
                        if (status == "pending") FriendRequest(
                            senderUid,
                            child.child("senderName").getValue(String::class.java) ?: "Unknown",
                            child.child("senderPhone").getValue(String::class.java) ?: "",
                            child.child("senderProfileImageUrl").getValue(String::class.java) ?: ""
                        ) else null
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            }
            requestsRef.addValueEventListener(requestListener)
            onDispose { requestsRef.removeEventListener(requestListener) }
        }
    }

    DisposableEffect(myUid) {
        if (myUid == null) onDispose {} else {
            val allRequestsRef = database.reference.child("friendRequests")
            val usersRef = database.reference.child("users")
            var requestsSnapshotCache: DataSnapshot? = null
            var usersSnapshotCache: DataSnapshot? = null
            fun updateSentRequests() {
                val requestSnapshot = requestsSnapshotCache ?: return
                val usersSnapshot = usersSnapshotCache ?: return
                sentRequests = requestSnapshot.children.mapNotNull { receiverSnapshot ->
                    val receiverUid = receiverSnapshot.key ?: return@mapNotNull null
                    val myRequest = receiverSnapshot.child(myUid)
                    val status = myRequest.child("status").getValue(String::class.java) ?: ""
                    if (status == "pending") {
                        val receiverUser = usersSnapshot.child(receiverUid)
                        SentFriendRequest(
                            receiverUid,
                            receiverUser.child("name").getValue(String::class.java) ?: "Unknown",
                            receiverUser.child("phone").getValue(String::class.java) ?: "",
                            receiverUser.child("profileImageUrl").getValue(String::class.java) ?: ""
                        )
                    } else null
                }
            }
            val requestListener = object : ValueEventListener { override fun onDataChange(snapshot: DataSnapshot) { requestsSnapshotCache = snapshot; updateSentRequests() }; override fun onCancelled(error: DatabaseError) {} }
            val usersListener = object : ValueEventListener { override fun onDataChange(snapshot: DataSnapshot) { usersSnapshotCache = snapshot; updateSentRequests() }; override fun onCancelled(error: DatabaseError) {} }
            allRequestsRef.addValueEventListener(requestListener); usersRef.addValueEventListener(usersListener)
            onDispose { allRequestsRef.removeEventListener(requestListener); usersRef.removeEventListener(usersListener) }
        }
    }
    ListenAcceptedFriends(auth, database) { friends = it }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            ScreenTitle("Friends", "Manage your trusted safety contacts")
            Spacer(Modifier.height(10.dp))
            ModernField(friendPhone, { friendPhone = it }, "Friend Phone Number")
            PrimaryButton("Send Friend Request") {
                if (friendPhone.isBlank()) Toast.makeText(context, "Enter a phone number", Toast.LENGTH_SHORT).show()
                else { sendFriendRequestByPhone(context, auth, database, friendPhone.trim()); friendPhone = "" }
            }
        }
        item { SectionTitle("Incoming Requests") }
        if (requests.isEmpty()) item { EmptyText("No friend requests yet.") } else items(requests) { request ->
            PersonCard(request.senderProfileImageUrl, request.senderName, request.senderPhone) {
                Row {
                    SmallAction("Accept", Safe) { acceptFriendRequest(context, auth, database, request.senderUid) }
                    Spacer(Modifier.width(8.dp))
                    SmallAction("Reject", Dark) { rejectFriendRequest(context, auth, database, request.senderUid) }
                }
            }
        }
        item { SectionTitle("Sent Requests") }
        if (sentRequests.isEmpty()) item { EmptyText("No pending sent requests.") } else items(sentRequests) { request ->
            PersonCard(request.receiverProfileImageUrl, request.receiverName, request.receiverPhone) { SmallAction("Cancel", Primary) { cancelFriendRequest(context, auth, database, request.receiverUid) } }
        }
        item { SectionTitle("Accepted Friends") }
        if (friends.isEmpty()) item { EmptyText("No accepted friends yet.") } else items(friends) { friend ->
            PersonCard(friend.profileImageUrl, friend.name, "${friend.phone} • ${if (friend.online) "Online" else "Offline"}") { SmallAction("Remove", Primary) { removeFriend(context, auth, database, friend.uid) } }
        }
    }
}

@Composable fun SectionTitle(text: String) { Text(text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, modifier = Modifier.padding(top = 4.dp)) }
@Composable fun EmptyText(text: String) { Text(text, color = Color.White, fontSize = 14.sp) }
@Composable fun SmallAction(text: String, color: Color, onClick: () -> Unit) { Button(onClick = onClick, shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = color), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Text(text, fontSize = 11.sp) } }

@Composable
fun PersonCard(imageUrl: String, title: String, subtitle: String, action: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = CardBg), elevation = CardDefaults.cardElevation(4.dp)) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            ProfileMiniImage(imageUrl)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White); Text(subtitle, color = Color.White, fontSize = 13.sp) }
            action()
        }
    }
}

@Composable
fun ProfileScreen(auth: FirebaseAuth, database: FirebaseDatabase) {
    val context = LocalContext.current
    val myUid = auth.currentUser?.uid
    var profile by remember { mutableStateOf(UserProfile()) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var shareLocation by remember { mutableStateOf(true) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var uploading by remember { mutableStateOf(false) }
    val imagePickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> selectedImageUri = uri }

    DisposableEffect(myUid) {
        if (myUid == null) onDispose {} else {
            val ref = database.reference.child("users").child(myUid)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val loaded = UserProfile(
                        snapshot.child("name").getValue(String::class.java) ?: "",
                        snapshot.child("phone").getValue(String::class.java) ?: "",
                        snapshot.child("email").getValue(String::class.java) ?: "",
                        snapshot.child("profileImageUrl").getValue(String::class.java) ?: "",
                        snapshot.child("online").getValue(Boolean::class.java) ?: false,
                        snapshot.child("lastSeen").getValue(Long::class.java) ?: 0L,
                        snapshot.child("latitude").getValue(Double::class.java) ?: 0.0,
                        snapshot.child("longitude").getValue(Double::class.java) ?: 0.0,
                        snapshot.child("shareLocation").getValue(Boolean::class.java) ?: true
                    )
                    profile = loaded; name = loaded.name; phone = loaded.phone; imageUrl = loaded.profileImageUrl; shareLocation = loaded.shareLocation
                }
                override fun onCancelled(error: DatabaseError) {}
            }
            ref.addValueEventListener(listener); onDispose { ref.removeEventListener(listener) }
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Profile", "Control your public safety information")
        Spacer(Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = CardBg), elevation = CardDefaults.cardElevation(6.dp)) {
            Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                ProfilePhotoPicker(selectedImageUri, imageUrl) { imagePickerLauncher.launch("image/*") }
                Spacer(Modifier.height(12.dp))
                Text(if (profile.online) "Status: Online" else "Status: Offline", color = if (profile.online) Safe else Muted, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) { Text("Share Location", fontWeight = FontWeight.Bold, color = Color.White); Text(if (shareLocation) "Friends can see you on map" else "You are hidden from friends", fontSize = 12.sp, color = Color.White) }
                    Switch(checked = shareLocation, onCheckedChange = { shareLocation = it })
                }
                ModernField(name, { name = it }, "Name")
                ModernField(phone, { phone = it }, "Phone")
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (myUid == null) return@Button
                        uploading = true
                        val saveProfile: (String) -> Unit = { finalImageUrl ->
                            val updates = mapOf<String, Any>("name" to name, "phone" to phone.trim(), "profileImageUrl" to finalImageUrl, "shareLocation" to shareLocation)
                            database.reference.child("users").child(myUid).updateChildren(updates)
                                .addOnSuccessListener { uploading = false; selectedImageUri = null; Toast.makeText(context, "Profile saved", Toast.LENGTH_SHORT).show() }
                                .addOnFailureListener { uploading = false; Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show() }
                        }
                        if (selectedImageUri != null) uploadProfileImageToCloudinary(context, selectedImageUri!!, { uploadedUrl -> imageUrl = uploadedUrl; saveProfile(uploadedUrl) }, { error -> uploading = false; Toast.makeText(context, "Upload error: $error", Toast.LENGTH_LONG).show() }) else saveProfile(imageUrl)
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    enabled = !uploading,
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Primary)
                ) { Text(if (uploading) "Saving..." else "Save Profile", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
fun MapsScreen(auth: FirebaseAuth, database: FirebaseDatabase, requestPermissions: (() -> Unit) -> Unit) {
    val context = LocalContext.current
    var myProfile by remember { mutableStateOf(UserProfile()) }
    var myLocation by remember { mutableStateOf<LatLng?>(null) }
    var friends by remember { mutableStateOf<List<FriendLocation>>(emptyList()) }
    var markerIcons by remember { mutableStateOf<Map<String, BitmapDescriptor>>(emptyMap()) }
    var myMarkerIcon by remember { mutableStateOf<BitmapDescriptor?>(null) }
    var selectedFriend by remember { mutableStateOf<FriendLocation?>(null) }
    var alerts by remember { mutableStateOf<List<AlertHistoryItem>>(emptyList()) }
    var mapLoaded by remember { mutableStateOf(false) }

    ListenMyProfile(auth, database) { myProfile = it }
    ListenAcceptedFriends(auth, database) {
        friends = it.filter { f -> f.shareLocation && f.latitude != 0.0 && f.longitude != 0.0 }
    }

    DisposableEffect(Unit) {
        val alertsRef = database.reference.child("alerts")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                alerts = snapshot.children.map { alertSnapshot ->
                    AlertHistoryItem(
                        alertSnapshot.key ?: "",
                        alertSnapshot.child("senderUid").getValue(String::class.java) ?: "",
                        alertSnapshot.child("senderName").getValue(String::class.java) ?: "Unknown",
                        alertSnapshot.child("type").getValue(String::class.java) ?: "",
                        alertSnapshot.child("message").getValue(String::class.java) ?: "",
                        alertSnapshot.child("latitude").getValue(Double::class.java) ?: 0.0,
                        alertSnapshot.child("longitude").getValue(Double::class.java) ?: 0.0,
                        alertSnapshot.child("timestamp").getValue(Long::class.java) ?: 0L
                    )
                }.sortedByDescending { it.timestamp }
            }

            override fun onCancelled(error: DatabaseError) {}
        }

        alertsRef.addValueEventListener(listener)

        onDispose {
            alertsRef.removeEventListener(listener)
        }
    }

    fun latestStatusForUser(uid: String): String {
        return alerts.firstOrNull { it.senderUid == uid }?.type ?: "NORMAL"
    }

    val defaultLocation = LatLng(44.4268, 26.1025)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(defaultLocation, 12f)
    }

    LaunchedEffect(mapLoaded, friends, alerts) {
        if (!mapLoaded) return@LaunchedEffect

        val icons = mutableMapOf<String, BitmapDescriptor>()

        friends.forEach { friend ->
            val status = latestStatusForUser(friend.uid)

            val icon = if (friend.profileImageUrl.isNotBlank()) {
                loadProfileMarkerIcon(context, friend.profileImageUrl, status)
            } else {
                BitmapDescriptorFactory.fromBitmap(
                    createDefaultQuestionMarkerBitmap(120, status)
                )
            }

            icon?.let {
                icons[friend.uid] = it
            }
        }

        markerIcons = icons
    }

    LaunchedEffect(mapLoaded, myProfile.profileImageUrl, alerts) {
        if (!mapLoaded) return@LaunchedEffect

        val myUid = auth.currentUser?.uid ?: ""
        val status = latestStatusForUser(myUid)

        myMarkerIcon = if (myProfile.profileImageUrl.isNotBlank()) {
            loadProfileMarkerIcon(context, myProfile.profileImageUrl, status)
        } else {
            BitmapDescriptorFactory.fromBitmap(
                createDefaultQuestionMarkerBitmap(120, status)
            )
        }
    }

    LaunchedEffect(Unit) {
        var firstLocationUpdate = true

        while (true) {
            val location = getLastKnownLocation(context)

            if (location != null) {
                val latLng = LatLng(location.latitude, location.longitude)
                myLocation = latLng
                updateMyLocationInFirebase(auth, database, location)

                if (firstLocationUpdate) {
                    cameraPositionState.position = CameraPosition.fromLatLngZoom(latLng, 15f)
                    firstLocationUpdate = false
                }
            }

            delay(5000)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenTitle("Live Map", "Tap markers to see friend status")
        Spacer(Modifier.height(12.dp))

        PrimaryButton("Update My Location", Info) {
            requestPermissions {
                val location = getLastKnownLocation(context)

                if (location != null) {
                    val latLng = LatLng(location.latitude, location.longitude)
                    myLocation = latLng
                    updateMyLocationInFirebase(auth, database, location)
                    cameraPositionState.position = CameraPosition.fromLatLngZoom(latLng, 15f)
                    Toast.makeText(context, "Location updated", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Location unavailable", Toast.LENGTH_SHORT).show()
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(420.dp),
            shape = RoundedCornerShape(22.dp),
            elevation = CardDefaults.cardElevation(6.dp)
        ) {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                onMapLoaded = {
                    mapLoaded = true
                },
                properties = MapProperties(
                    mapStyleOptions = MapStyleOptions.loadRawResourceStyle(
                        context,
                        R.raw.map_style
                    )
                )
            ) {
                myLocation?.let {
                    Marker(
                        state = MarkerState(position = it),
                        title = "You",
                        snippet = "Your current location",
                        icon = myMarkerIcon
                    )
                }

                friends.forEach { friend ->
                    Marker(
                        state = MarkerState(
                            position = LatLng(friend.latitude, friend.longitude)
                        ),
                        title = friend.name,
                        snippet = "Status: ${latestStatusForUser(friend.uid)}",
                        icon = markerIcons[friend.uid],
                        onClick = {
                            selectedFriend = friend
                            false
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        selectedFriend?.let { friend ->
            val status = latestStatusForUser(friend.uid)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(friend.name, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)

                    Text(
                        "Status: $status",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (status) {
                            "SOS" -> Danger
                            "DANGER" -> Warning
                            "SAFE" -> Safe
                            else -> Muted
                        }
                    )

                    Spacer(Modifier.height(10.dp))

                    PrimaryButton("Get Directions", Info) {
                        openGoogleMapsNavigation(context, friend.latitude, friend.longitude)
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("Friends visible on map: ${friends.size}", fontSize = 14.sp, color = Color.White)
    }
}
@Composable
fun DangerAlertsScreen(auth: FirebaseAuth, database: FirebaseDatabase, requestPermissions: (() -> Unit) -> Unit) {
    val context = LocalContext.current
    var dangerMessage by remember { mutableStateOf("") }
    var customMessage by remember { mutableStateOf("") }
    var acceptedFriends by remember { mutableStateOf<List<FriendLocation>>(emptyList()) }

    ListenAcceptedFriends(auth, database) { acceptedFriends = it }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle(
            "Custom Alerts",
            "Send danger alerts, utility requests or emergency product requests"
        )

        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            elevation = CardDefaults.cardElevation(6.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                ModernField(dangerMessage, { dangerMessage = it }, "Danger message")

                Spacer(Modifier.height(10.dp))

                PrimaryButton("Send Danger Alert", Warning) {
                    if (acceptedFriends.isEmpty()) {
                        Toast.makeText(context, "Add accepted friends first", Toast.LENGTH_SHORT).show()
                    } else if (dangerMessage.isBlank()) {
                        Toast.makeText(context, "Write a danger message", Toast.LENGTH_SHORT).show()
                    } else {
                        requestPermissions {
                            val location = getLastKnownLocation(context)

                            saveAlertToFirebase(
                                auth = auth,
                                database = database,
                                type = "DANGER",
                                customMessage = dangerMessage,
                                location = location,
                                receivers = acceptedFriends
                            )

                            showSafeSignalNotification(
                                context = context,
                                title = "⚠️ Danger Alert Sent",
                                message = dangerMessage
                            )

                            sendDangerAlert(context, acceptedFriends, dangerMessage)
                            dangerMessage = ""
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))

                ModernField(
                    customMessage,
                    { customMessage = it },
                    "Utilities or emergency product request"
                )

                Spacer(Modifier.height(10.dp))

                PrimaryButton("Send Message", Safe) {
                    if (acceptedFriends.isEmpty()) {
                        Toast.makeText(context, "Add accepted friends first", Toast.LENGTH_SHORT).show()
                    } else if (customMessage.isBlank()) {
                        Toast.makeText(context, "Write a message", Toast.LENGTH_SHORT).show()
                    } else {
                        requestPermissions {
                            val message = "CUSTOM REQUEST\n$customMessage"

                            sendSmsToFriends(context, acceptedFriends, message)

                            showSafeSignalNotification(
                                context = context,
                                title = "✅ Message Sent",
                                message = "Your custom request was sent to trusted friends"
                            )

                            customMessage = ""
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text("Accepted friends: ${acceptedFriends.size}", color = Color.White)
            }
        }
    }
}

@Composable
fun EmptyCard(text: String) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = CardBg), elevation = CardDefaults.cardElevation(4.dp)) {
        Text(text, modifier = Modifier.padding(18.dp), color = Color.White)
    }
}

@Composable
fun ModernInfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = CardBg), elevation = CardDefaults.cardElevation(4.dp)) {
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

@Composable
fun AboutScreen() {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("About Safe Signal", "Personal safety, location sharing and emergency communication")
        Spacer(Modifier.height(14.dp))
        ModernInfoCard { Text("Safe Signal is a personal safety application designed to help users quickly communicate their status and location during emergency situations.", fontSize = 14.sp, color = Color.White) }
        Spacer(Modifier.height(12.dp))
        ModernInfoCard {
            Text("Main Features", fontWeight = FontWeight.Bold, color = Color.White); Spacer(Modifier.height(8.dp))
            Text("• Send SOS alerts with live location", color = Color.White)
            Text("• Notify trusted friends instantly", color = Color.White)
            Text("• View friends in real-time on the map", color = Color.White)
            Text("• Public alert history for awareness", color = Color.White)
            Text("• Emergency shelters displayed on map", color = Color.White)
            Text("• Safe check-in functionality", color = Color.White)
        }
        Spacer(Modifier.height(12.dp))
        ModernInfoCard { Text("Purpose", fontWeight = FontWeight.Bold, color = Color.White); Spacer(Modifier.height(8.dp)); Text("The goal of this application is to improve personal safety and response time in critical situations such as accidents, dangerous environments, or natural disasters.", fontSize = 14.sp, color = Color.White) }
        Spacer(Modifier.height(12.dp))
        ModernInfoCard {
            Text("Future Development", fontWeight = FontWeight.Bold, color = Color.White); Spacer(Modifier.height(8.dp))
            Text("• Push notifications for alerts", color = Color.White)
            Text("• Automatic emergency detection", color = Color.White)
            Text("• Partnerships with emergency services", color = Color.White)
            Text("• Advanced real-time tracking features", color = Color.White)
        }
        Spacer(Modifier.height(18.dp)); Text("Developed by: Antonio David Dinu", fontSize = 12.sp, color = Color.White); Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun HistoryScreen(auth: FirebaseAuth, database: FirebaseDatabase) {
    val myUid = auth.currentUser?.uid
    var alerts by remember { mutableStateOf<List<AlertHistoryItem>>(emptyList()) }

    DisposableEffect(myUid) {
        if (myUid == null) {
            onDispose {}
        } else {
            val alertsRef = database.reference.child("alerts")

            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<AlertHistoryItem>()

                    for (alertSnapshot in snapshot.children) {
                        val senderUid = alertSnapshot.child("senderUid").getValue(String::class.java) ?: ""
                        val isMyAlert = senderUid == myUid
                        val isSentToMe = alertSnapshot.child("receivers").child(myUid).getValue(Boolean::class.java) == true

                        if (isMyAlert || isSentToMe) {
                            list.add(
                                AlertHistoryItem(
                                    alertId = alertSnapshot.key ?: "",
                                    senderUid = senderUid,
                                    senderName = alertSnapshot.child("senderName").getValue(String::class.java) ?: "Unknown",
                                    type = alertSnapshot.child("type").getValue(String::class.java) ?: "",
                                    message = alertSnapshot.child("message").getValue(String::class.java) ?: "",
                                    latitude = alertSnapshot.child("latitude").getValue(Double::class.java) ?: 0.0,
                                    longitude = alertSnapshot.child("longitude").getValue(Double::class.java) ?: 0.0,
                                    timestamp = alertSnapshot.child("timestamp").getValue(Long::class.java) ?: 0L
                                )
                            )
                        }
                    }

                    alerts = list.sortedByDescending { it.timestamp }
                }

                override fun onCancelled(error: DatabaseError) {}
            }

            alertsRef.addValueEventListener(listener)

            onDispose {
                alertsRef.removeEventListener(listener)
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        ScreenTitle("Friends Alert History", "Only alerts between you and accepted friends appear here")
        Spacer(Modifier.height(12.dp))

        if (alerts.isEmpty()) {
            EmptyCard("No alerts from you or your friends yet.")
        } else {
            LazyColumn {
                items(alerts) { alert ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBg),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                alert.type,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = when (alert.type) {
                                    "SOS" -> Danger
                                    "SAFE" -> Safe
                                    else -> Warning
                                }
                            )

                            Spacer(Modifier.height(4.dp))
                            Text("From: ${alert.senderName}", fontWeight = FontWeight.Bold, color = Color.White)
                            Text(alert.message, color = Color.White)
                            Text("Time: ${formatTimestamp(alert.timestamp)}", color = Color.White, fontSize = 13.sp)

                            if (alert.latitude != 0.0 && alert.longitude != 0.0) {
                                Text(
                                    "Location: https://maps.google.com/?q=${alert.latitude},${alert.longitude}",
                                    color = Info,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SheltersScreen() {
    val context = LocalContext.current
    val shelters = listOf(
        ShelterLocation("Adăpost Protecție Civilă - Piața Unirii", "War Shelter", "Piața Unirii, București", 44.4275, 26.1025, "Adăpost pentru situații de urgență"),
        ShelterLocation("Adăpost Protecție Civilă - Universitate", "War Shelter", "Universitate, București", 44.4355, 26.1029, "Adăpost pentru civili în caz de pericol"),
        ShelterLocation("Adăpost Protecție Civilă - Piața Victoriei", "War Shelter", "Piața Victoriei, București", 44.4520, 26.0875, "Adăpost pentru situații de urgență"),
        ShelterLocation("Centru Homeless - Gara de Nord", "Homeless Shelter", "Gara de Nord, București", 44.4463, 26.0742, "Centru pentru persoane fără adăpost"),
        ShelterLocation("Centru Social - Obor", "Homeless Shelter", "Obor, București", 44.4521, 26.1256, "Sprijin pentru persoane vulnerabile"),
        ShelterLocation("Centru Social - Rahova", "Homeless Shelter", "Rahova, București", 44.4038, 26.0634, "Centru social pentru persoane fără adăpost")
    )
    var selectedShelter by remember { mutableStateOf<ShelterLocation?>(null) }
    val cameraPositionState = rememberCameraPositionState { position = CameraPosition.fromLatLngZoom(LatLng(44.4268, 26.1025), 12f) }
    Column {
        ScreenTitle("Shelters", "Tap a shelter marker to see details")
        Spacer(Modifier.height(12.dp))
        Card(modifier = Modifier.fillMaxWidth().height(430.dp), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = CardBg), elevation = CardDefaults.cardElevation(6.dp)) {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                properties = MapProperties(
                    mapStyleOptions = MapStyleOptions.loadRawResourceStyle(
                        context,
                        R.raw.map_style
                    )
                )
            ) {
                shelters.forEach { shelter -> Marker(state = MarkerState(position = LatLng(shelter.latitude, shelter.longitude)), title = shelter.name, snippet = shelter.type, onClick = { selectedShelter = shelter; false }) }
            }
        }
        Spacer(Modifier.height(12.dp))
        selectedShelter?.let { shelter ->
            ModernInfoCard {
                Text(shelter.name, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Primary)
                Spacer(Modifier.height(6.dp))
                Text("Type: ${shelter.type}", fontSize = 14.sp, color = Color.White)
                Text("Address: ${shelter.address}", fontSize = 14.sp, color = Color.White)
                Text(shelter.description, fontSize = 14.sp, color = Color.White)
                Spacer(Modifier.height(12.dp))
                PrimaryButton("Get Directions", Info) { openGoogleMapsNavigation(context, shelter.latitude, shelter.longitude) }
            }
        }
    }
}

@Composable
fun ListenAcceptedFriends(auth: FirebaseAuth, database: FirebaseDatabase, onFriendsLoaded: (List<FriendLocation>) -> Unit) {
    val myUid = auth.currentUser?.uid
    DisposableEffect(myUid) {
        if (myUid == null) onDispose {} else {
            val friendsRef = database.reference.child("friends").child(myUid)
            val usersRef = database.reference.child("users")
            var friendUids: List<String> = emptyList()
            var usersSnapshotCache: DataSnapshot? = null
            fun updateFriends() {
                val usersSnapshot = usersSnapshotCache ?: return
                if (friendUids.isEmpty()) { onFriendsLoaded(emptyList()); return }
                onFriendsLoaded(friendUids.mapNotNull { uid ->
                    val userSnapshot = usersSnapshot.child(uid)
                    if (userSnapshot.exists()) FriendLocation(
                        uid,
                        userSnapshot.child("name").getValue(String::class.java) ?: "Unknown",
                        userSnapshot.child("phone").getValue(String::class.java) ?: "",
                        userSnapshot.child("latitude").getValue(Double::class.java) ?: 0.0,
                        userSnapshot.child("longitude").getValue(Double::class.java) ?: 0.0,
                        userSnapshot.child("profileImageUrl").getValue(String::class.java) ?: "",
                        userSnapshot.child("online").getValue(Boolean::class.java) ?: false,
                        userSnapshot.child("lastSeen").getValue(Long::class.java) ?: 0L,
                        userSnapshot.child("shareLocation").getValue(Boolean::class.java) ?: true
                    ) else null
                })
            }
            val friendsListener = object : ValueEventListener { override fun onDataChange(snapshot: DataSnapshot) { friendUids = snapshot.children.mapNotNull { it.key }; updateFriends() }; override fun onCancelled(error: DatabaseError) {} }
            val usersListener = object : ValueEventListener { override fun onDataChange(snapshot: DataSnapshot) { usersSnapshotCache = snapshot; updateFriends() }; override fun onCancelled(error: DatabaseError) {} }
            friendsRef.addValueEventListener(friendsListener); usersRef.addValueEventListener(usersListener)
            onDispose { friendsRef.removeEventListener(friendsListener); usersRef.removeEventListener(usersListener) }
        }
    }
}

@Composable
fun ListenMyProfile(auth: FirebaseAuth, database: FirebaseDatabase, onProfileLoaded: (UserProfile) -> Unit) {
    val myUid = auth.currentUser?.uid
    DisposableEffect(myUid) {
        if (myUid == null) onDispose {} else {
            val ref = database.reference.child("users").child(myUid)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    onProfileLoaded(UserProfile(
                        snapshot.child("name").getValue(String::class.java) ?: "",
                        snapshot.child("phone").getValue(String::class.java) ?: "",
                        snapshot.child("email").getValue(String::class.java) ?: "",
                        snapshot.child("profileImageUrl").getValue(String::class.java) ?: "",
                        snapshot.child("online").getValue(Boolean::class.java) ?: false,
                        snapshot.child("lastSeen").getValue(Long::class.java) ?: 0L,
                        snapshot.child("latitude").getValue(Double::class.java) ?: 0.0,
                        snapshot.child("longitude").getValue(Double::class.java) ?: 0.0,
                        snapshot.child("shareLocation").getValue(Boolean::class.java) ?: true
                    ))
                }
                override fun onCancelled(error: DatabaseError) {}
            }
            ref.addValueEventListener(listener); onDispose { ref.removeEventListener(listener) }
        }
    }
}

fun sendFriendRequestByPhone(context: Context, auth: FirebaseAuth, database: FirebaseDatabase, phone: String) {
    val myUid = auth.currentUser?.uid ?: return
    database.reference.child("users").child(myUid).addListenerForSingleValueEvent(object : ValueEventListener {
        override fun onDataChange(mySnapshot: DataSnapshot) {
            val myName = mySnapshot.child("name").getValue(String::class.java) ?: "Unknown"
            val myPhone = mySnapshot.child("phone").getValue(String::class.java) ?: ""
            val myImage = mySnapshot.child("profileImageUrl").getValue(String::class.java) ?: ""
            database.reference.child("users").orderByChild("phone").equalTo(phone.trim()).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (!snapshot.exists()) { Toast.makeText(context, "No user found with this phone", Toast.LENGTH_LONG).show(); return }
                    val receiverSnapshot = snapshot.children.first(); val receiverUid = receiverSnapshot.key
                    if (receiverUid == null) { Toast.makeText(context, "User error", Toast.LENGTH_SHORT).show(); return }
                    if (receiverUid == myUid) { Toast.makeText(context, "You cannot add yourself", Toast.LENGTH_SHORT).show(); return }
                    val requestData = mapOf("senderName" to myName, "senderPhone" to myPhone, "senderProfileImageUrl" to myImage, "status" to "pending")
                    database.reference.child("friendRequests").child(receiverUid).child(myUid).setValue(requestData)
                        .addOnSuccessListener { Toast.makeText(context, "Friend request sent", Toast.LENGTH_SHORT).show() }
                        .addOnFailureListener { Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show() }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
        }
        override fun onCancelled(error: DatabaseError) {}
    })
}

fun acceptFriendRequest(context: Context, auth: FirebaseAuth, database: FirebaseDatabase, senderUid: String) {
    val myUid = auth.currentUser?.uid ?: return
    database.reference.updateChildren(hashMapOf<String, Any?>("friends/$myUid/$senderUid" to true, "friends/$senderUid/$myUid" to true, "friendRequests/$myUid/$senderUid" to null))
        .addOnSuccessListener { Toast.makeText(context, "Friend accepted", Toast.LENGTH_SHORT).show() }
        .addOnFailureListener { Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show() }
}
fun rejectFriendRequest(context: Context, auth: FirebaseAuth, database: FirebaseDatabase, senderUid: String) { val myUid = auth.currentUser?.uid ?: return; database.reference.child("friendRequests").child(myUid).child(senderUid).removeValue().addOnSuccessListener { Toast.makeText(context, "Request rejected", Toast.LENGTH_SHORT).show() }.addOnFailureListener { Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show() } }
fun cancelFriendRequest(context: Context, auth: FirebaseAuth, database: FirebaseDatabase, receiverUid: String) { val myUid = auth.currentUser?.uid ?: return; database.reference.child("friendRequests").child(receiverUid).child(myUid).removeValue().addOnSuccessListener { Toast.makeText(context, "Request cancelled", Toast.LENGTH_SHORT).show() }.addOnFailureListener { Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show() } }
fun removeFriend(context: Context, auth: FirebaseAuth, database: FirebaseDatabase, friendUid: String) { val myUid = auth.currentUser?.uid ?: return; database.reference.updateChildren(hashMapOf<String, Any?>("friends/$myUid/$friendUid" to null, "friends/$friendUid/$myUid" to null)).addOnSuccessListener { Toast.makeText(context, "Friend removed", Toast.LENGTH_SHORT).show() }.addOnFailureListener { Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show() } }

fun saveAlertToFirebase(auth: FirebaseAuth, database: FirebaseDatabase, type: String, customMessage: String, location: Location?, receivers: List<FriendLocation>) {
    val myUid = auth.currentUser?.uid ?: return
    database.reference.child("users").child(myUid).addListenerForSingleValueEvent(object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
            val senderName = snapshot.child("name").getValue(String::class.java) ?: "Unknown"
            val alertRef = database.reference.child("alerts").push(); val alertId = alertRef.key ?: return
            val receiverMap = receivers.associate { it.uid to true }
            val data = mapOf<String, Any>("alertId" to alertId, "senderUid" to myUid, "senderName" to senderName, "type" to type, "message" to customMessage, "latitude" to (location?.latitude ?: 0.0), "longitude" to (location?.longitude ?: 0.0), "timestamp" to ServerValue.TIMESTAMP, "receivers" to receiverMap)
            alertRef.setValue(data)
        }
        override fun onCancelled(error: DatabaseError) {}
    })
}

fun openGoogleMapsNavigation(context: Context, latitude: Double, longitude: Double) { try { val intent = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$latitude,$longitude")); intent.setPackage("com.google.android.apps.maps"); context.startActivity(intent) } catch (e: Exception) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=$latitude,$longitude"))) } }
fun formatTimestamp(timestamp: Long): String = if (timestamp == 0L) "Unknown" else try { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(timestamp)) } catch (e: Exception) { "Unknown" }

fun uploadProfileImageToCloudinary(context: Context, imageUri: Uri, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
    try { MediaManager.get().upload(imageUri).unsigned(CLOUDINARY_UPLOAD_PRESET).callback(object : UploadCallback {
        override fun onStart(requestId: String?) {}
        override fun onProgress(requestId: String?, bytes: Long, totalBytes: Long) {}
        override fun onSuccess(requestId: String?, resultData: MutableMap<Any?, Any?>?) { val secureUrl = resultData?.get("secure_url") as? String; if (secureUrl != null) onSuccess(secureUrl) else onError("No image URL returned") }
        override fun onError(requestId: String?, error: ErrorInfo?) { onError(error?.description ?: "Unknown Cloudinary error") }
        override fun onReschedule(requestId: String?, error: ErrorInfo?) { onError(error?.description ?: "Upload rescheduled") }
    }).dispatch() } catch (e: Exception) { onError(e.message ?: "Upload failed") }
}

fun updateMyLocationInFirebase(auth: FirebaseAuth, database: FirebaseDatabase, location: Location) {
    val userId = auth.currentUser?.uid ?: return
    database.reference.child("users").child(userId).updateChildren(mapOf<String, Any>("latitude" to location.latitude, "longitude" to location.longitude, "online" to true, "lastSeen" to ServerValue.TIMESTAMP))
}
fun setupOnlinePresence(auth: FirebaseAuth, database: FirebaseDatabase) { val userId = auth.currentUser?.uid ?: return; val userRef = database.reference.child("users").child(userId); userRef.child("online").onDisconnect().setValue(false); userRef.child("lastSeen").onDisconnect().setValue(ServerValue.TIMESTAMP); userRef.child("online").setValue(true); userRef.child("lastSeen").setValue(ServerValue.TIMESTAMP) }
fun setUserOnline(auth: FirebaseAuth, database: FirebaseDatabase, online: Boolean) { val userId = auth.currentUser?.uid ?: return; database.reference.child("users").child(userId).updateChildren(mapOf<String, Any>("online" to online, "lastSeen" to ServerValue.TIMESTAMP)) }

fun sendSOS(context: Context, friends: List<FriendLocation>) { val location = getLastKnownLocation(context); val locationText = if (location != null) "My location: https://maps.google.com/?q=${location.latitude},${location.longitude}" else "Location could not be obtained."; sendSmsToFriends(context, friends, "SOS ALERT!\nI need help.\n$locationText") }
fun sendSafeCheckIn(context: Context, friends: List<FriendLocation>) { val location = getLastKnownLocation(context); val locationText = if (location != null) "My location: https://maps.google.com/?q=${location.latitude},${location.longitude}" else "Location unavailable."; sendSmsToFriends(context, friends, "SAFE CHECK-IN\nI am safe.\n$locationText") }
fun sendDangerAlert(context: Context, friends: List<FriendLocation>, dangerMessage: String) { val location = getLastKnownLocation(context); val locationText = if (location != null) "Location: https://maps.google.com/?q=${location.latitude},${location.longitude}" else "Location unavailable."; sendSmsToFriends(context, friends, "DANGER ALERT!\n$dangerMessage\n$locationText") }
fun sendSmsToFriends(context: Context, friends: List<FriendLocation>, message: String) { try { val smsManager = SmsManager.getDefault(); if (friends.isEmpty()) { Toast.makeText(context, "No accepted friends found", Toast.LENGTH_LONG).show(); return }; var sentCount = 0; friends.forEach { friend -> if (friend.phone.isNotBlank()) { smsManager.sendTextMessage(friend.phone.trim(), null, message, null, null); sentCount++ } }; Toast.makeText(context, "SMS sent to $sentCount friend(s)", Toast.LENGTH_LONG).show() } catch (e: Exception) { Toast.makeText(context, "SMS error: ${e.message}", Toast.LENGTH_LONG).show() } }

fun getLastKnownLocation(context: Context): Location? {
    val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
    val providers = locationManager.getProviders(true)
    var bestLocation: Location? = null
    for (provider in providers) { val location = locationManager.getLastKnownLocation(provider) ?: continue; if (bestLocation == null || location.accuracy < bestLocation.accuracy) bestLocation = location }
    return bestLocation
}
fun saveOfflineAlert(context: Context, message: String, friends: List<FriendLocation>) {
    val phones = friends
        .map { it.phone.trim() }
        .filter { it.isNotBlank() }
        .toSet()

    context.getSharedPreferences("safe_signal_data", Context.MODE_PRIVATE)
        .edit()
        .putString("offline_alert", message)
        .putStringSet("offline_alert_phones", phones)
        .apply()
}

suspend fun loadProfileMarkerIcon(context: Context, imageUrl: String, status: String = "NORMAL"): BitmapDescriptor? = try {
    val imageLoader = ImageLoader(context)
    val request = ImageRequest.Builder(context).data(imageUrl).allowHardware(false).build()
    val result = imageLoader.execute(request)
    if (result is SuccessResult) BitmapDescriptorFactory.fromBitmap(createCircleBitmapWithStatusRing(result.drawable.toBitmap(120, 120), 120, status)) else null
} catch (e: Exception) { null }

fun createCircleBitmapWithStatusRing(bitmap: Bitmap, size: Int, status: String): Bitmap {
    val scaledBitmap = Bitmap.createScaledBitmap(bitmap, size, size, false)
    val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 10f; color = when (status) { "SOS" -> android.graphics.Color.RED; "DANGER" -> android.graphics.Color.rgb(255, 165, 0); "SAFE" -> android.graphics.Color.rgb(0, 180, 70); else -> android.graphics.Color.LTGRAY } }
    val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(scaledBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
    val radius = size / 2f
    canvas.drawCircle(radius, radius, radius - 8f, imagePaint)
    canvas.drawCircle(radius, radius, radius - 6f, ringPaint)
    return output
}

fun createDefaultQuestionMarkerBitmap(size: Int, status: String): Bitmap {
    val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    val radius = size / 2f

    val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.rgb(58, 13, 20)
    }

    val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 10f
        color = when (status) {
            "SOS" -> android.graphics.Color.RED
            "DANGER" -> android.graphics.Color.rgb(255, 165, 0)
            "SAFE" -> android.graphics.Color.rgb(0, 180, 70)
            else -> android.graphics.Color.LTGRAY
        }
    }

    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(255, 45, 61)
        textSize = size * 0.56f
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    canvas.drawCircle(radius, radius, radius - 8f, fillPaint)
    canvas.drawCircle(radius, radius, radius - 6f, ringPaint)

    val y = radius - (textPaint.descent() + textPaint.ascent()) / 2f
    canvas.drawText("?", radius, y, textPaint)

    return output
}

fun createCircleBitmap(bitmap: Bitmap, size: Int): Bitmap {
    val scaledBitmap = Bitmap.createScaledBitmap(bitmap, size, size, false)
    val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(output)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(scaledBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
    canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
    return output
}

@Composable
fun ProfileMiniImage(imageUrl: String) {
    if (imageUrl.isNotBlank()) AsyncImage(model = imageUrl, contentDescription = "Profile image", modifier = Modifier.size(50.dp).clip(CircleShape))
    else Surface(modifier = Modifier.size(50.dp).clip(CircleShape), color = SoftRed) { Box(contentAlignment = Alignment.Center) { Text("?", color = Primary, fontWeight = FontWeight.Bold) } }
}

fun startSafeSignalBackgroundService(context: Context) {
    val intent = Intent(context, LocationForegroundService::class.java)
    ContextCompat.startForegroundService(context, intent)
}

fun showSafeSignalNotification(context: Context, title: String, message: String) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val channelId = "safe_signal_alerts"
        val manager = context.getSystemService(NotificationManager::class.java)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "SafeSignal Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    } catch (_: Exception) {
    }
}
