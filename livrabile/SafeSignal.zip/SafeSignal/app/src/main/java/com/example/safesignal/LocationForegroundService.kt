package com.example.safesignal

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.telephony.SmsManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

class LocationForegroundService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var serviceStarted = false
    private var offlineSosSending = false

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
    }

    private fun startForegroundService() {
        val channelId = "location_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Location Tracking",
                NotificationManager.IMPORTANCE_LOW
            )

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("SafeSignal")
            .setContentText("📍 Tracking location and waiting for Offline SOS")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .build()

        startForeground(1, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!serviceStarted) {
            serviceStarted = true
            startBackgroundLoop()
        }

        return START_STICKY
    }

    private fun startBackgroundLoop() {
        scope.launch {
            while (true) {
                val location = getLastKnownLocation()

                if (location != null) {
                    updateLocationInFirebase(location)
                }

                checkAndSendOfflineSOS(location)

                delay(5000)
            }
        }
    }

    private fun getLastKnownLocation(): Location? {
        val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) return null

        val providers = locationManager.getProviders(true)
        var bestLocation: Location? = null

        for (provider in providers) {
            val loc = locationManager.getLastKnownLocation(provider) ?: continue
            if (bestLocation == null || loc.accuracy < bestLocation.accuracy) {
                bestLocation = loc
            }
        }

        return bestLocation
    }

    private fun updateLocationInFirebase(location: Location) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        FirebaseDatabase.getInstance()
            .reference
            .child("users")
            .child(userId)
            .updateChildren(
                mapOf(
                    "latitude" to location.latitude,
                    "longitude" to location.longitude,
                    "online" to true
                )
            )
    }

    private fun checkAndSendOfflineSOS(location: Location?) {
        if (offlineSosSending) return

        val prefs = getSharedPreferences("safe_signal_data", Context.MODE_PRIVATE)
        val savedMessage = prefs.getString("offline_alert", null) ?: return

        offlineSosSending = true

        val savedPhones = prefs.getStringSet("offline_friend_phones", emptySet())
            ?.filter { it.isNotBlank() }
            ?.map { it.trim() }
            ?.distinct()
            ?: emptyList()

        if (savedPhones.isNotEmpty()) {
            sendOfflineSmsToPhones(savedPhones, savedMessage, location)
            offlineSosSending = false
            return
        }

        val myUid = FirebaseAuth.getInstance().currentUser?.uid
        if (myUid == null) {
            offlineSosSending = false
            return
        }

        val database = FirebaseDatabase.getInstance()

        database.reference.child("friends").child(myUid).get()
            .addOnSuccessListener { friendsSnapshot ->
                val friendUids = friendsSnapshot.children.mapNotNull { it.key }

                if (friendUids.isEmpty()) {
                    offlineSosSending = false
                    return@addOnSuccessListener
                }

                database.reference.child("users").get()
                    .addOnSuccessListener { usersSnapshot ->
                        val phones = friendUids.mapNotNull { uid ->
                            usersSnapshot.child(uid).child("phone").getValue(String::class.java)
                        }.filter { it.isNotBlank() }
                            .map { it.trim() }
                            .distinct()

                        sendOfflineSmsToPhones(phones, savedMessage, location)
                        offlineSosSending = false
                    }
                    .addOnFailureListener {
                        offlineSosSending = false
                    }
            }
            .addOnFailureListener {
                offlineSosSending = false
            }
    }

    private fun sendOfflineSmsToPhones(phones: List<String>, savedMessage: String, location: Location?) {
        if (phones.isEmpty()) return

        val prefs = getSharedPreferences("safe_signal_data", Context.MODE_PRIVATE)

        val locationText = if (location != null) {
            "\nMy location: https://maps.google.com/?q=${location.latitude},${location.longitude}"
        } else {
            "\nLocation unavailable."
        }

        val finalMessage = savedMessage + locationText

        try {
            val smsManager = SmsManager.getDefault()

            phones.forEach { phone ->
                val parts = smsManager.divideMessage(finalMessage)
                smsManager.sendMultipartTextMessage(phone.trim(), null, parts, null, null)
            }

            prefs.edit()
                .remove("offline_alert")
                .remove("offline_friend_phones")
                .apply()

            showNotification(
                "📡 Offline SOS Sent",
                "Offline SOS was sent automatically when signal returned"
            )
        } catch (_: Exception) {
            // Nu ștergem alerta dacă SMS-ul nu s-a trimis. Serviciul va reîncerca automat.
        }
    }

    private fun showNotification(title: String, message: String) {
        val channelId = "safe_signal_alerts"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "SafeSignal Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        val manager = getSystemService(NotificationManager::class.java)
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
